# (c) HYBRID
import os
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup

FSUB_MSG = """
Hello {} 👋

Your request to join **{}** has been received. in order for you to get accepted to the channel join the channel by clicking the button below
"""

START_TEXT = """
Hello {} 👋

I am can set **Force Sub** for channel approvals.

which means if someone wants to join your channel (request approval enabled channels) they must also need to join/send request to another channel as you configure.

Check **❔ Help** menu for more details
"""

SKB = [
    [
        InlineKeyboardButton("❔ Help", callback_data="help"),
        InlineKeyboardButton("❕ About", callback_data="about")
    ],
    [
        InlineKeyboardButton("➕ Add Channel", callback_data="addch")
    ]
]
START_KB = InlineKeyboardMarkup(SKB)

CHAN_MSG = """
Main Channel:
Title: {}
ID: {}

Fsub:
Title: {}
ID: {}
Link: {}
"""

HELP_MESSAGE = """
**How to use the bot** ❔

> **Will update soon**
> **Will update soon**

Usage: 
    **Will update soon**

❕ Note: Bot must have **Invite Users Via Link** permission
                                          
💬 Support: @Hybrid_Chat
"""

ABOUT_MESSAGE = """
**About @**

 🤖 Version : {}
 📝 Language: Python
 📚 Library : Pyrogram 2.0
 ☁️ Server  : VPS
 👤 Creator : @Hybrid_Vamp
 💬 Support : @Hybrid_Chat
 📢 Updates : @HybridUpdates
 👤 Total users : {}
 """

RESTART_TXT = """
<b>Bᴏᴛ Rᴇsᴛᴀʀᴛᴇᴅ !
📅 Dᴀᴛᴇ : <code>{}</code>
⏰ Tɪᴍᴇ : <code>{}</code>
🌐 Tɪᴍᴇᴢᴏɴᴇ : <code>Asia/Kolkata</code></b>
"""

CHANGE_LOG="""
ℹ️ **Version: {}**

🚧 Updates:
- **Updates soon...**

🚩 Fixes:
- **Updates soon...**

**Channel**: @HybridUpdates
"""
