# HYBRID (c)

import re
import random
import asyncio
from pyrogram import Client, filters
from pyrogram.errors import FloodWait
from pyrogram.raw import functions
from urllib.parse import urlparse, parse_qs
from pyrogram.raw.functions.account import CheckUsername
from pyrogram.types import CallbackQuery, ChatMemberUpdated, ChatPermissions, ChatPrivileges, Message, InlineKeyboardButton, InlineKeyboardMarkup

from hybrid import app, OWNER, CLIENTS, RUNNING, LOG_ID
from hybrid.plugins.error import capture_err
from hybrid.database.db import save_string, check_string, rem_words, remove_word
from hybrid.plugins.func import is_valid, get_range, get_words, get_valid_words, check_un, claim_un, parse_url

@app.on_message(filters.command("delete") & filters.user(OWNER))
@capture_err
async def delete_chan_un(_, message):
    msg = await message.reply_text("Processing...")
    ask_num = await app.ask(text="Send usernam/id to delete:", chat_id=message.from_user.id, filters=filters.text)
    word = ask_num.text
    await ask_num.sent_message.delete()
    await ask_num.delete()
    if word.startswith("@"):
        word = word.replace("@", "")
        ch_id = "12345"
    elif word.startswith("-100"):
        ch_id = word
    else:
        return await msg.edit("⚠️ Send a correct username (@username) or a chat id (-100xxxxxxx). Process stopped")
    
    keyboard = [
        [
            InlineKeyboardButton("❌ Delete UN", callback_data=f"del#{ch_id}#{word}"),
            InlineKeyboardButton("🔻 Close", callback_data="close"),
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await msg.edit(f"🔻 **Are you sure you wanna delete @{word}**", reply_markup=reply_markup)

@app.on_message(filters.command("transfer") & filters.user(OWNER))
@capture_err
async def transfer(_, message):
    msg = await message.reply_text("Processing...")
    chan = await app.ask(text="send channel id:", chat_id=message.from_user.id, filters=filters.text)
    resp = chan.text
    await chan.sent_message.delete()
    if not resp.startswith("-100"):
        await message.reply_text("❌ Send valid channel ID, process stopped")
        return
    ch_id = int(resp)
    new = await app.ask(text="send user id to transfer ownership:", chat_id=message.from_user.id, filters=filters.text)
    new_id = int(new)
    await new.sent_message.delete()
    owner = await find_admin(ch_id, new_id)
    if not owner:
        await msg.edit("Owner of the chat not found, check inputs and try again")
        return
    chat = await owner.get_chat(ch_id)
    title = chat.title
    user = await owner.get_me()
    await msg.edit(f"Found owner of channel **{title}** as **{user.first_name}**")
    pass_ask = await app.ask(text=f"Send 2FA password of the user session **{user.first_name}**:", chat_id=message.from_user.id, filters=filters.text)
    password = pass_ask.text
    await pass_ask.sent_message.delete()
    await pass_ask.delete()
    try:
        transfer = await owner.invoke(EditCreator(channel=ch_id, user_id=new_id, password=password))
        if transfer:
            await msg.edit(f"```Transfer Log:\n {transfer}```")
    except Exception as e:
        await msg.edit(f"```Error:\n{e}```")

@app.on_message(filters.command("rclaim") & filters.user(OWNER))
@capture_err
async def rclaim(_, message):
    msg = await message.reply_text("⏳")

    ask_num = await app.ask(text="send range from:", chat_id=message.from_user.id, filters=filters.text)
    num = int(ask_num.text)
    ask_num2 = await app.ask(text="send range to:", chat_id=message.from_user.id, filters=filters.text)
    num2 = int(ask_num2.text)
    await ask_num.sent_message.delete()
    await ask_num.delete()
    await ask_num2.sent_message.delete()
    await ask_num2.delete()
    
    word_list = await get_range(num, num2, msg)
    if not word_list:
        await msg.reply_text("Could not process worlds list, check logs")
        return

    RUNNING.append("hybrid")

    tot = len(word_list)
    checked = 0
    skipped = 0
    invalid = 0
    error = 0
    inw = 0

    for word in word_list:
        if not RUNNING:
            break
        try:
            check = await check_string(word)
            if check:
                skipped += 1
                continue

            await save_string(word)
            valid = is_valid(word)
            if not valid:
                inw += 1
                checked += 1
                continue
            ucheck = await check_un(word, msg)
            if not ucheck:
                invalid += 1
                checked += 1
                msg = await msg.edit(f"Range: {num} - {num2}\nTotal fetched words: `{tot}`\nChecked: `{checked}` words\nSkipped: `{skipped}`\nInvalid: `{invalid}`\nInvalid Wors: `{inw}`\nLast checked: @{word}")
                continue
            if ucheck == "Flood":
                await remove_word(word)
                await message.reply_text("❌ Every User client got floodwait, stopping process...")
                RUNNING.clear()
                break
            success, ch_id = await claim_un(word, msg)
            if success:
                keyboard = [
                    [
                        InlineKeyboardButton("🔻 Close", callback_data="close")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await message.reply_text(f"✅ Username @{word} claimed by {success} user session", reply_markup=reply_markup)
                await app.send_message(LOG_ID, f"✅ Username @{word} claimed by {success} user session")
                continue
            else:
                await remove_word(word)
                await message.reply_text(f"❌ Username @{word} available but could not claim\n\nStopping process.")
                RUNNING.clear()
                break

        except ValueError as e:
            error += 1
            text = msg.text + f"\n\n```Error {error}: \n{e}```"
            await msg.edit(text)
            print(f"Error setting username for {word}: {e}")
        except FloodWait as e:
            error += 1
            text = msg.text + f"\n\n```Error {error}: \n{e}```"
            await msg.edit(text)
            await asyncio.sleep(e.value)
        except Exception as e:
            error += 1
            text = msg.text + f"\n\n```Error {error}: \n{e}```"
            await msg.edit(text)
            print(f"An unexpected error occurred: {e}")

        checked += 1

        try:
            msg = await msg.edit(f"Range: {num} - {num2}\nTotal fetched words: `{tot}`\nChecked: `{checked}` words\nSkipped: `{skipped}`\nInvalid: `{invalid}`\nInvalid Wors: `{inw}`\nLast checked: @{word}")
        except FloodWait as e:
            await asyncio.sleep(e.x)

        if checked == tot:
            await message.reply_text(f"checked `{checked}` words and no success")
            print("No successful username found.")
    await msg.reply_text("✅ **Process completed**")

@app.on_message(filters.command("claim") & filters.user(OWNER))
@capture_err
async def claim(_, message):
    errormsg = await message.reply_text("Logs:")
    msg = await message.reply_text("⏳")

    ask_num = await app.ask(text="send number of letters:", chat_id=message.from_user.id, filters=filters.text)
    num = int(ask_num.text)
    await ask_num.sent_message.delete()
    await ask_num.delete()
    
    word_list = get_words(num)
    if not word_list:
        await msg.edit("Coudn't fetch Words list")
        await errormsg.delete()
        return
    RUNNING.append("hybrid")
    tot = len(word_list)
    checked = 0
    skipped = 0
    invalid = 0
    error = 0
    inw = 0

    for word in word_list:
        try:
            check = await check_string(word)
            if check:
                skipped += 1
                continue

            await save_string(word)
            valid = is_valid(word)
            if not valid:
                inw += 1
                continue
            ucheck = await check_un(word, errormsg)
            if not ucheck:
                invalid += 1
                checked += 1
                msg = await msg.edit(f"Letters: {num}\nTotal fetched words: `{tot}`\nChecked: `{checked}` words\nSkipped: `{skipped}`\nInvalid: `{invalid}`\nInvalid Wors: `{inw}`\nLast checked: @{word}")
                continue
            if ucheck == "Flood":
                await remove_word(word)
                await message.reply_text("❌ Every User client got floodwait, stopping process...")
                RUNNING.clear()
                break
            success, ch_id = await claim_un(word, errormsg)
            if success:
                keyboard = [
                    [
                        InlineKeyboardButton("🔻 Close", callback_data="close")
                    ]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await message.reply_text(f"✅ Username @{word} claimed by {success} user session", reply_markup=reply_markup)
                await app.send_message(LOG_ID, f"✅ Username @{word} claimed by {success} user session")
            else:
                await remove_word(word)
                await message.reply_text(f"❌ Username @{word} available but could not claim\n\nStopping process.")
                RUNNING.clear()
                break

        except ValueError as e:
            error += 1
            text = msg.text + f"\n\n```Error {error}:\n{e}```"
            await msg.edit(text)
            print(f"Error setting username for {word}: {e}")
        except FloodWait as e:
            error += 1
            text = msg.text + f"\n\n```Floodwait {error}:\n{e}```"
            await msg.edit(text)
            await asyncio.sleep(e.value)
        except Exception as e:
            error += 1
            text = msg.text + f"\n\n```Error {error}:\n{e}```"
            await msg.edit(text)
            print(f"An unexpected error occurred: {e}")

        checked += 1

        try:
            msg = await msg.edit(f"Letters: {num}\nTotal fetched words: `{tot}`\nChecked: `{checked}` words\nSkipped: `{skipped}`\nInvalid: `{invalid}`\nInvalid Wors: `{inw}`\nLast checked: @{word}")
        except FloodWait as e:
            await asyncio.sleep(e.x)

        if checked == tot:
            await msg.edit(f"checked `{checked}` words and no success")
            print("No successful username found.")
    await msg.reply_text("✅ **Process completed**")

@app.on_message(filters.command("make") & filters.user(OWNER))
@capture_err
async def set_un(_, message):
    msg = await message.reply_text("Processing....")
    newun = await app.ask(text="Send new username:", chat_id=message.from_user.id, filters=filters.text)
    word = newun.text
    if word.startswith("@"):
        word = word.replace("@", "")
    await newun.sent_message.delete()
    await newun.delete()
    while True:
        try:
            success, ch_id = await claim_un(word, msg)
            if success:
                await msg.edit(f"✅ Username @{word} claimed")
                await app.send_message(LOG_ID, f"✅ Username @{word} claimed")
                break
            else:
                await msg.edit(f"❌ Could not make @{word}")
                break
        except Exception as e:
            break

@app.on_message(filters.command("cleardb") & filters.user(OWNER))
@capture_err
async def rem_words_sql(_, message):
    msg = await message.reply_text("**Cleaning DB...**")
    await rem_words()
    await msg.edit("**Database cleared**")

@app.on_message(filters.command("join") & filters.user(OWNER))
@capture_err
async def join_link(_, message):
    msg = await message.reply_text("⌛")
    newun = await app.ask(text="Send the username or link to join:", chat_id=message.from_user.id, filters=filters.text)
    word = newun.text

    if word.startswith("@"):
        words = word
        word = word.replace("@", "")
    elif word.startswith("t.me"):
        word = "https://" + word
        words = word
    elif re.match(r'^https?://t\.me', word):
        words = word
    else:
        await newun.sent_message.delete()
        await newun.delete()
        await msg.edit("**Give the correct username or link**")
        return

    await newun.sent_message.delete()
    await newun.delete()
    
    msg = await msg.edit(f"**Chat: {words}\n\nJoining Logs:**")
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            name = user.first_name
            joined = await uapp.join_chat(word)
            msgs = msg.text + f"\n{name} joined the chat"
            msg = await msg.edit(msgs)
            continue
        except Exception as e:
            msgs = msg.text + f"\n{name} failed to join chat: {e}\n"
            msg = await msg.edit(msgs)
            continue
    text = msg.text + "\n\n✅ Process completed"
    await msg.edit(text, disable_web_page_preview=True)      

@app.on_message(filters.command("leave") & filters.user(OWNER))
@capture_err
async def leave_chat(_, message):
    msg = await message.reply_text("⌛")
    newun = await app.ask(text="Send the username or link to leave:", chat_id=message.from_user.id, filters=filters.text)
    word = newun.text

    if word.startswith("@"):
        words = word
        word = word.replace("@", "")
    elif word.startswith("t.me"):
        word = "https://" + word
        words = word
    elif re.match(r'^https?://t\.me', word):
        words = word
    else:
        await newun.sent_message.delete()
        await newun.delete()
        await msg.edit("**Give the correct username or link**")
        return

    await newun.sent_message.delete()
    await newun.delete()
    
    msg = await msg.edit(f"**Chat: {words}\n\nLeaving Logs:**")
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            name = user.first_name
            joined = await uapp.leave_chat(word)
            msgs = msg.text + f"\n{name} left the chat"
            msg = await msg.edit(msgs)
            continue
        except Exception as e:
            msgs = msg.text + f"\n{name} failed to leave the chat: {e}\n"
            msg = await msg.edit(msgs)
            continue
    text = msg.text + "\n\n✅ Process completed"
    await msg.edit(text, disable_web_page_preview=True) 

@app.on_message(filters.command("startbot") & filters.user(OWNER))
@capture_err
async def start_bot_link(_, message):
    msg = await message.reply_text("⌛")
    newun = await app.ask(text="Send me the  bot link to start:", chat_id=message.from_user.id, filters=filters.text)
    word = newun.text

    if word.startswith("t.me"):
        word = "https://" + word
        words = word
    elif word.startswith("@"):
        words = word
        word_is = word.replace("@", "")
        word = "https://t.me/" + word_is
    elif re.match(r'^https?://t\.me', word):
        words = word
    else:
        await newun.sent_message.delete()
        await newun.delete()
        await msg.edit("**Give the correct username or link**")
        return

    await newun.sent_message.delete()
    await newun.delete()

    username, start_param = parse_url(word)

    msg = await msg.edit(f"**Link: {words}\n\nUsername: @{username}\nParameter: ``{start_param}``\n\nJoining Logs:**")
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            name = user.first_name
            peer_bot = await uapp.resolve_peer(username)
            await uapp.invoke(
                functions.messages.StartBot(
                    bot = peer_bot,
                    peer = peer_bot,
                    random_id = user.id,
                    start_param = start_param
                )
            )
            msgs = msg.text + f"\n{name} started the bot"
            msg = await msg.edit(msgs)
            continue
        except Exception as e:
            msgs = msg.text + f"\n{name} failed to start the bot: {e}\n"
            msg = await msg.edit(msgs)
            continue
    text = msg.text + "\n\n✅ Process completed"
    await msg.edit(text, disable_web_page_preview=True)
